# থিয়েটার ফিনিক্স — Version 2.0 (CMS-ready)

এই সংস্করণটি আগের ডিজাইনকে রেখে **নিজে থেকে কনটেন্ট আপডেট করার জন্য প্রস্তুত** করা হয়েছে। এখানে Decap CMS + Netlify Identity/Git Gateway ব্যবহার করা হয়েছে। Decap CMS browser-এর `/admin/` route-এ content manager দেয় এবং authenticated অবস্থায় content repository-তে পরিবর্তন লিখতে পারে।

## আপনি কী কী নিজে বদলাতে পারবেন
- সাইটের নাম, tagline, hero text, Vision, Mission, Story intro
- নাট্যপ্রযোজনা: নতুন নাটক যোগ / edit / delete / poster upload
- চলচ্চিত্র: নতুন film যোগ / edit / delete / poster upload
- আমাদের মানুষ: নাম, দায়িত্ব, ছবি
- সংবাদ ও ঘোষণা
- আসন্ন আয়োজন
- কর্মশালা
- গ্যালারি: মঞ্চ / মহড়া / কর্মশালা / চলচ্চিত্রের ছবি

## একবারের setup
1. ZIP-এর ভেতরের `theatre_phoenix_pro` folder-এর সবকিছু একটি GitHub repository-তে upload করুন। Repository-এর default branch `main` রাখুন।
2. Netlify-তে বর্তমান site-টিকে ওই GitHub repository-এর সঙ্গে connect করুন।
3. Netlify → Integrations/Identity থেকে **Netlify Identity** enable করুন।
4. Identity registration-কে **Invite only** রাখা ভালো।
5. Netlify → Identity/Services থেকে **Git Gateway** enable করুন।
6. প্রথমবার `/admin/` খুলে invited account দিয়ে login করুন।

### তারপর কী হবে
`https://আপনার-সাইট.netlify.app/admin/` খুললেই একটি dashboard পাবেন। সেখানে content edit করে **Publish** করলে পরিবর্তন repository-তে commit হবে এবং Netlify নতুন deploy করে website update করবে।

## গুরুত্বপূর্ণ
- এই ZIP-এর `admin/config.yml`-এ এখনকার temporary Netlify URL দেওয়া আছে; নিজের custom domain হলে এটি বদলে দেবেন।
- `assets/uploads/` ফোল্ডারটি CMS-এর media upload location।
- ভবিষ্যৎ নাটক/film-এর জন্য listing page dynamic; নতুন item যোগ করলে listing-এ নিজে থেকে দেখা যাবে।
- `content.html?id=...&type=production|film` generic detail page হিসেবে ব্যবহার করা যায়।
- বর্তমান `অবরুদ্ধ`, `ক্যালাইডোস্কোপ` ও `Crime Never Best` page-ও JSON content থেকে তথ্য নেয়।

## Netlify-তে ZIP drag-and-drop দিয়ে শুধু deploy করলে কী হবে?
CMS login/publish workflow কাজ করবে না, কারণ CMS-এর authenticated Git backend-এর জন্য Git repository connection প্রয়োজন। Static site হিসেবে অবশ্য website চলবে।
