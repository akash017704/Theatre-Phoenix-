(function(){
  const menu=document.querySelector('.menu'), nav=document.querySelector('.navlinks');
  if(menu&&nav){menu.setAttribute('aria-expanded','false');menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});}
  const path=(location.pathname.split('/').pop()||'index.html');
  document.querySelectorAll('.navlinks a[href]').forEach(a=>{
    const href=a.getAttribute('href');
    if(href===path){a.classList.add('active');const parent=a.closest('.dropdown');if(parent){parent.querySelector('.dropbtn').classList.add('active');}}
    a.addEventListener('click',()=>{nav&&nav.classList.remove('open');});
  });
  document.querySelectorAll('.dropbtn').forEach(btn=>btn.addEventListener('click',e=>{
    if(window.innerWidth<=800){e.preventDefault();btn.parentElement.classList.toggle('open');}
  }));
  const lb=document.createElement('div');lb.className='lightbox';lb.innerHTML='<button aria-label="বন্ধ করুন">×</button><img alt="">';document.body.appendChild(lb);
  const lbImg=lb.querySelector('img');
  document.querySelectorAll('.gallery img').forEach(img=>img.addEventListener('click',()=>{lbImg.src=img.src;lbImg.alt=img.alt;lb.classList.add('open');document.body.style.overflow='hidden';}));
  const close=()=>{lb.classList.remove('open');document.body.style.overflow='';};
  lb.addEventListener('click',e=>{if(e.target===lb||e.target.tagName==='BUTTON')close();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
  const top=document.createElement('button');top.className='backtop';top.setAttribute('aria-label','উপরে যান');top.textContent='↑';document.body.appendChild(top);
  window.addEventListener('scroll',()=>top.classList.toggle('show',window.scrollY>500),{passive:true});top.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
})();
